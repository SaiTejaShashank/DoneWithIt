import { NavigationContainer } from '@react-navigation/native';
import  React,{useEffect, useState} from 'react';
import OfflineNotice from './app/components/OfflineNotice';
import AppNavigator from './app/navigation/AppNavigator';
import AuthNavigator from './app/navigation/AuthNavigator';
import AuthContext from './app/auth/context';
import authStorage from './app/auth/storage';
import {AppLoading} from 'expo';
import LoginScreen from './app/Screens/LoginScreen';
import WelcomeScreen from './app/Screens/WelcomeScreen';
import NavigateScreen from './app/Practice/navigateScreen';
import jwtDecode from 'jwt-decode';
import AppPicker from './app/components/AppPicker';

/*const categories = [{
  label: "Furniture",
  value: 1,
},
{
  label: "Clothing",
  value: 2,
},
{
  label: "Electronics",
  value: 3,
},
{
  label: "Vehicles",
  value: 4,
}];*/

/*export default function App() {

  const [imageUris,setImageUris]=useState([]);

  const handleAdd=uri=>{
    setImageUris([...imageUris,uri]);
  }

  const handleRemove=uri=>{
    setImageUris(imageUris.filter(imageUri=>imageUri!==uri));
  }
  return(
  <NavigateScreen/>
  ) 




}*/

export default function App() {

  const [user,setUser]=useState();
  const [isReady,setIsReady]=useState(false);



 
  const restoreUser=async ()=>{
    const user=await authStorage.getUser();
    if(user) setUser(user);
  }

  useEffect(()=>{
    restoreUser();
  },[]);

  return(
    <AuthContext.Provider value={{user,setUser}}>
    <OfflineNotice/>
   <NavigationContainer>
    {user?<AppNavigator/>:<AuthNavigator/>}
   </NavigationContainer>
   </AuthContext.Provider>
    );
}






