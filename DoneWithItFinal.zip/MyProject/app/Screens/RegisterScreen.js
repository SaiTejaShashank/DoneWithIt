import React, { useState } from "react";
import { StyleSheet } from "react-native";
import * as Yup from "yup";
import usersApi from "../api/users";

import Screen from "../components/Screen";
import { Form, FormField, SubmitButton,ErrorMessage } from "../components/forms";
import authApi from "../api/auth";
import auth from "../api/auth";
import useAuthe from "../auth/useAuth";
import useApi from "../hooks/useApi";
import { ActivityIndicator } from "react-native";

const validationSchema = Yup.object().shape({
  name: Yup.string().required().label("Name"),
  email: Yup.string().required().email().label("Email"),
  password: Yup.string().required().min(4).label("Password"),
});

function RegisterScreen() {

  const registerApi=useApi(usersApi.register);
  const loginApi=useApi(authApi.login);

  const [error,setError]=useState();
  const {logIn}=useAuthe();

  const handleSubmit=async (userInfo)=>{
    const result=await  usersApi.register(userInfo);
    if(!result.ok){
      if(result.data) setError(result.data.error);
      else{
        setError("An unexpected error occurred.");
        console.log(result);
      }
      return;
  }

  const {data:authToken}=await authApi.login(
      userInfo.email,
      userInfo.password
  );
  logIn(authToken);

};

//<ActivityIndicator visible={registerApi.loading||loginApi.loading}/>


  return (

    <>
     
    <Screen style={styles.container}>
   
     
      <Form
        initialValues={{ name: "", email: "", password: "" }}
        onSubmit={handleSubmit}
        validationSchema={validationSchema}
      >
        <ErrorMessage
        error="A user with given email already exists."
        visible={error}
      />
        <FormField
          autoCorrect={false}
          icon="account"
          name="name"
          placeholder="Name"
        />
        <FormField
          autoCapitalize="none"
          autoCorrect={false}
          icon="email"
          keyboardType="email-address"
          name="email"
          placeholder="Email"
          textContentType="emailAddress"
        />
        <FormField
          autoCapitalize="none"
          autoCorrect={false}
          icon="lock"
          name="password"
          placeholder="Password"
          secureTextEntry
          textContentType="password"
        />
        <SubmitButton title="Register" />
      </Form>
    </Screen>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
  },
});

export default RegisterScreen;
