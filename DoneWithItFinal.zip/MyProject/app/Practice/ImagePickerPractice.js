import React,{useState,useEffect} from 'react';
import * as ImagePicker from 'expo-image-picker';
import { Button,Image } from 'react-native';
import Screen from '../components/Screen';
import ImageInput from '../components/ImageInput';

function ImagePickerPractice(props) {

    const [imageUri,setImageUri]=useState();

  

  const requestPermission=async ()=>{
    const result= await ImagePicker.requestCameraPermissionsAsync();
    if(!result.granted){
      alert("You need to enable permission to access");
    }
  }

  const selectImage=async ()=>{
    try{
    const result= await ImagePicker.launchImageLibraryAsync();
    if(!result.cancelled){
      setImageUri(result.uri);
    }
    }
    catch(error){
      console.log("Error reading Image",error);

    }
  }

  useEffect(()=>{
    requestPermission();
  },[]);

  return (
    
      <Screen>
        <Button title="Select Image" onPress={selectImage}/>
        <Image source={{uri:imageUri}} style={{width:200,height:200}}/>        
      </Screen>
   
  );
}

export default ImagePickerPractice;