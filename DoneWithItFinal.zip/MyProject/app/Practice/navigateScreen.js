import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import React from 'react';
import {Button,Text,View} from 'react-native';




const Stack=createStackNavigator();

const Tweets=({navigation})=>{

    return(
    <View>
        <Text>Tweets</Text>
        <Button title="View Tweet" onPress={()=>navigation.navigate("TweetDetails")}
        />
    </View>
    );
    };

const TweetDetails=()=>{
    return(
    <View>
        <Text>Tweet Details</Text>
    </View>
);
    };







const StackNavigator=()=>{
    return(
    <Stack.Navigator>
        <Stack.Screen name="Tweets" component={Tweets}/>
        <Stack.Screen name="TweetDetails" component={TweetDetails}/>
    </Stack.Navigator>
);
    };

export default function NavigateScreen(){
    return(
        <NavigationContainer>
           <StackNavigator/>
        </NavigationContainer>
    )
}