
import {createStackNavigator} from "@react-navigation/stack";
import { NavigationContainer } from '@react-navigation/native';
import React from 'react';


import WelcomeScreen from '../Screens/WelcomeScreen';
import LoginScreen from '../Screens/LoginScreen';
import RegisterScreen from '../Screens/RegisterScreen';

const St=createStackNavigator();

const AuthNavigator=()=>{

    return(
    
    
    <St.Navigator>
        <St.Screen name="Welcome" component={WelcomeScreen} options={{headerShown:false}}/>
        <St.Screen name="Login" component={LoginScreen}/>
        <St.Screen name="Register" component={RegisterScreen}/>
    </St.Navigator>

    );
       
};

export default AuthNavigator;
