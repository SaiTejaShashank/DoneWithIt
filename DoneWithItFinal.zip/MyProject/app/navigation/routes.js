export default Object.freeze({
    LISTING_DETAILS:"ListingDetails",
})