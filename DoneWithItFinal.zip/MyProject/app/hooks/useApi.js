import { useState } from "react";
export default useApi=(apiFunc)=>{
    const [data,setData]=useState([]);
    const [error,setError]=useState(false);
    const [loading,setLoading]=useState(true);

    const request=async ()=>{
        

        setLoading(true);
        const response=await apiFunc();
        setLoading(false);

        
        setError(!response.ok);
        setData(response.data);

        return response;
    }

    return {request,data,error,loading};
}